import hashlib
import json
import random
import re
import time
from urllib.parse import quote, unquote, urlencode, urlsplit

from base.spider import Spider as BaseSpider

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------

HOME = "https://www.bilibili.com"
API = "https://api.bilibili.com"
SEARCH_HOME = "https://search.bilibili.com"
NAV_URL = API + "/x/web-interface/nav"
SEARCH_URL = API + "/x/web-interface/wbi/search/type"
APP_SEARCH_URL = "https://app.bilibili.com/x/v2/search"
VIEW_URL = API + "/x/web-interface/view"
PAGE_LIST_URL = API + "/x/player/pagelist"
PLAY_URL = API + "/x/player/wbi/playurl"

WBI_FALLBACK_IMG = "ea1db124af3c7062474693fa704f4ff8"
WBI_FALLBACK_SUB = "2636a7d717dbc939181429f61e609721"

PAGE_SIZE = 20
REQUEST_TIMEOUT_SECONDS = 15
MIN_REQUEST_GAP_MS = 300
SEARCH_CACHE_TTL = 60  # 搜索结果短暂缓存：减少重复请求，降低触发风控概率
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
)

# WBI 混淆表
MIXIN_KEY_ENC_TAB = [
    46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5, 49,
    33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13, 37, 48, 7, 16, 24, 55, 40,
    61, 26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11,
    36, 20, 34, 44, 52,
]
WBI_STRIP_CHARS = "!'()*"

# 听书过滤词表
AUDIO_HINTS = (
    "有声小说", "有声书", "有声剧", "有声读物", "有声", "听书", "评书", "相声",
    "广播剧", "演播", "朗读", "诵读", "长书", "连播", "说书", "单口", "播讲",
    "多人剧", "小说剧",
)
NOISE_HINTS = (
    "一口气看完", "漫推", "漫画", "解说", "讲解", "解读", "动画", "鬼畜", "混剪",
    "沙雕", "速看", "reaction", "预告", "游戏实况", "配音秀",
)
GENRE_HINTS = (
    "评书", "相声", "广播剧", "听书", "演播", "朗读", "诵读", "长书", "连播",
    "说书", "单口", "播讲",
)
AUDIO_TYPE_ID = 195  # B 站「动态漫.广播剧」分区

# 发现页分类
# (type_id, 分类名, 搜索关键词, 默认排序)
CATEGORIES = (
    ("hot", "热门推荐", "有声小说", "click"),
    ("bd", "广播剧", "广播剧 全集", None),
    ("ps", "评书", "评书 单田芳", None),
    ("xs", "相声", "相声 德云社", None),
    ("xy", "悬疑", "悬疑有声小说", None),
    ("xh", "玄幻仙侠", "玄幻小说听书", None),
    ("mz", "名著悦读", "世界名著朗读", None),
)

# 精选主播
HOSTS = (
    ("周建龙", "鬼吹灯 · 盗墓笔记", "周建龙 有声小说"),
    ("紫襟", "十宗罪 · 心理罪", "紫襟 有声小说"),
    ("王明军", "三体 · 白鹿原", "王明军 有声小说"),
    ("艾宝良", "午夜恐怖故事", "艾宝良 有声小说"),
    ("李野默", "平凡的世界", "李野默 有声小说"),
    ("青雪", "悬疑 · 盗墓", "青雪 有声小说"),
    ("光合积木", "默读 · 破云", "光合积木 广播剧"),
    ("音熊联萌", "魔道祖师", "音熊联萌 广播剧"),
    ("729声工场", "杀破狼 · 全职高手", "729声工场 广播剧"),
    ("边江工作室", "盗墓笔记", "边江工作室 广播剧"),
    ("北斗企鹅", "一人之下 · 全职高手", "北斗企鹅 广播剧"),
    ("冠声文化", "天官赐福 · 撒野", "冠声文化 广播剧"),
    ("单田芳", "隋唐演义 · 白眉大侠", "单田芳 评书"),
    ("刘兰芳", "岳飞传 · 杨家将", "刘兰芳 评书"),
    ("袁阔成", "三国演义", "袁阔成 评书"),
    ("田连元", "水浒传 · 小八义", "田连元 评书"),
    ("王玥波", "聊斋 · 大隋唐", "王玥波 评书"),
    ("连丽如", "东汉演义 · 三国", "连丽如 评书"),
    ("郭德纲", "德云社 · 单口相声", "郭德纲 相声"),
    ("岳云鹏", "德云社 · 五环之歌", "岳云鹏 相声"),
    ("马三立", "传统相声", "马三立 相声"),
    ("侯宝林", "相声大师", "侯宝林 相声"),
    ("高峰", "德云社 · 传统活", "高峰 相声"),
    ("大斌", "遮天 · 完美世界", "大斌 有声小说"),
    ("桑梓", "斗破苍穹", "桑梓 有声小说"),
    ("头陀渊", "凡人修仙传", "头陀渊 有声小说"),
    ("牛大宝", "都市 · 玄幻", "牛大宝 有声小说"),
    ("张震", "张震讲故事", "张震讲故事 有声小说"),
    ("刘琮", "悬疑 · 科幻", "刘琮 有声小说"),
    ("徐涛", "世界名著", "徐涛 朗读"),
    ("李立宏", "舌尖上的中国", "李立宏 朗读"),
    ("方明", "经典散文", "方明 朗读"),
)

TITLE_TAG_RE = re.compile(r"<[^>]+>")


# ---------------------------------------------------------------------------
# 纯函数
# ---------------------------------------------------------------------------

def _wbi_file_key(url):
    name = str(url or "").rsplit("/", 1)[-1]
    return name.rsplit(".", 1)[0] if "." in name else name


def _mixin_key(img_url, sub_url):
    joined = _wbi_file_key(img_url) + _wbi_file_key(sub_url)
    return "".join(joined[i] for i in MIXIN_KEY_ENC_TAB)


def _wbi_sign(params, mixin):
    """返回带 w_rid / wts 的新参数 dict（按键名排序）。"""
    signed = {}
    for key, value in params.items():
        signed[str(key)] = "".join(
            ch for ch in str(value) if ch not in WBI_STRIP_CHARS
        )
    signed["wts"] = str(int(time.time()))
    signed = dict(sorted(signed.items()))
    query = urlencode(signed)
    signed["w_rid"] = hashlib.md5((query + mixin).encode("utf-8")).hexdigest()
    return signed


def _clean_title(value):
    return TITLE_TAG_RE.sub("", str(value or "")).strip()


def _parse_duration(value):
    """搜索接口时长：秒数、数字字符串，或 "5152:33" / "1:02:03"。"""
    if value is None:
        return 0
    if isinstance(value, bool):
        return 0
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value).strip()
    if not text:
        return 0
    parts = text.split(":")
    if len(parts) >= 2:
        total = 0
        for part in parts:
            total = total * 60 + _safe_int(part)
        return total
    return _safe_int(text)


def _safe_int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return 0


def _duration_text(seconds):
    seconds = _safe_int(seconds)
    if seconds <= 0:
        return ""
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    if hours > 0:
        return "%d:%02d:%02d" % (hours, minutes, secs)
    return "%d:%02d" % (minutes, secs)


def _normalize_pic(value):
    url = str(value or "").strip()
    if url.startswith("//"):
        return "https:" + url
    if url.startswith("http://"):
        return "https://" + url[7:]
    return url


def _has_hint(text, hints):
    lowered = text.casefold()
    return any(hint in lowered for hint in hints)


def _is_audiobook_item(item, keyword):
    """只保留有声小说/听书类内容。"""
    title = str(item.get("title") or "")
    meta = "%s %s" % (item.get("description") or "", item.get("tag") or "")
    if _has_hint("%s %s" % (title, meta), NOISE_HINTS):
        return False

    seconds = _parse_duration(item.get("duration"))
    if _has_hint(title, AUDIO_HINTS) and seconds >= 300:
        return True
    if _safe_int(item.get("typeid")) == AUDIO_TYPE_ID and seconds >= 600:
        return True
    if _has_hint(meta, AUDIO_HINTS) and seconds >= 1800:
        return True
    if _has_hint(str(keyword or ""), GENRE_HINTS) and seconds >= 1800:
        return True
    return False


def _gen_buvid3():
    hex_digits = "0123456789ABCDEF"

    def block(n):
        return "".join(random.choice(hex_digits) for _ in range(n))

    uuid = "%s-%s-4%s-%x%s-%s" % (
        block(8), block(4), block(3),
        8 + random.randint(0, 3), block(3), block(12),
    )
    suffix = "%05d" % random.randint(0, 99999)
    return uuid + suffix + "infoc"


def _year_of(pubdate):
    value = _safe_int(pubdate)
    if value > 10 ** 12:  # 毫秒时间戳
        value //= 1000
    if value <= 0:
        return ""
    try:
        return time.strftime("%Y", time.localtime(value))
    except (OverflowError, OSError, ValueError):
        return ""


def _safe_label(value):
    return str(value or "").replace("$", "＄").replace("#", "＃").strip()


# ---------------------------------------------------------------------------
# 爬虫
# ---------------------------------------------------------------------------

class Spider(BaseSpider):
    # -- 生命周期 ----------------------------------------------------------

    def init(self, extend=""):
        if isinstance(extend, dict):
            options = extend
        elif extend:
            parsed = json.loads(extend)
            if not isinstance(parsed, dict):
                raise ValueError("Site.ext 必须是 JSON 物件")
            options = parsed
        else:
            options = {}

        self.options = options
        self._cookies = {}
        self._img_url = ""
        self._sub_url = ""
        self._mixin = ""
        self._ready = False
        self._last_request_at = 0.0
        self._book_cache = {}
        self._search_cache = {}
        self._last_error = ""

        cookie = str(options.get("cookie") or "").strip()
        if cookie:
            for segment in cookie.split(";"):
                key, sep, value = segment.strip().partition("=")
                if sep and key:
                    self._cookies[key] = value
        if "buvid3" not in self._cookies:
            self._cookies["buvid3"] = _gen_buvid3()
            self._cookies["b_nut"] = str(int(time.time() * 1000))
        self._log("init 完成，登录Cookie=%s，分类数=%d"
                  % ("已配置" if str(options.get("cookie") or "").strip() else "未配置",
                     len(CATEGORIES)))

    def getName(self):
        return "阿B听书"

    def destroy(self):
        self.options = {}
        self._cookies = {}
        self._img_url = ""
        self._sub_url = ""
        self._mixin = ""
        self._ready = False
        self._book_cache = {}
        self._search_cache = {}
        self._last_error = ""

    # -- 首页 / 分类 / 搜索 -------------------------------------------------

    def homeContent(self, filter):
        result = {
            "class": [
                {"type_id": tid, "type_name": name}
                for tid, name, _keyword, _order in CATEGORIES
            ] + [
                {"type_id": "hosts", "type_name": "精选主播"},
                {"type_id": "tools", "type_name": "诊断工具", "type_flag": "1"},
            ]
        }
        if filter:
            row = {
                "key": "order", "name": "排序", "init": "totalrank",
                "value": [
                    {"n": "综合排序", "v": "totalrank"},
                    {"n": "最多播放", "v": "click"},
                    {"n": "最新发布", "v": "pubdate"},
                    {"n": "最多收藏", "v": "stow"},
                ],
            }
            result["filters"] = {
                tid: [dict(row, value=[dict(v) for v in row["value"]])]
                for tid, _name, _kw, _order in CATEGORIES
            }
        return result

    def categoryContent(self, tid, pg, filter, extend):
        del filter
        extend = extend if isinstance(extend, dict) else {}
        tid = str(tid or "")
        page = self._page_number(pg)

        if tid == "hosts":
            result = self._page([self._folder_card(item) for item in HOSTS], page)
            self._log("分类 tid=hosts -> %d 个主播" % len(result["list"]))
            return result
        if tid == "tools":
            result = self._page(self._tool_cards(), page)
            self._log("分类 tid=tools -> %d 张工具卡" % len(result["list"]))
            return result

        keyword = ""
        default_order = None
        if tid.startswith("kw/"):
            keyword = unquote(tid[3:])
        else:
            for cat_id, _name, cat_kw, cat_order in CATEGORIES:
                if cat_id == tid:
                    keyword, default_order = cat_kw, cat_order
                    break

        if not keyword:
            return self._page([], page)

        order = str(extend.get("order") or "") or default_order
        books, total, pagecount = self._robust(
            "分类「%s」" % keyword,
            lambda: self._search(keyword, page, order),
            ([], 0, 1),
        )
        result = self._page(
            [self._card(book) for book in books], page, total, pagecount
        )
        self._log("分类 tid=%s kw=%s pg=%s order=%s -> %d 条 (total=%s pagecount=%s)"
                  % (tid, keyword, page, order or "-", len(result["list"]),
                     total, result["pagecount"]))
        if not result["list"]:
            self._log("警告：分类为空 tid=%s，last_error=%s"
                      % (tid, self._last_error or "无"))
        return result

    def searchContent(self, key, quick, pg="1"):
        del quick
        query = str(key or "").strip()
        page = self._page_number(pg)
        if not query:
            return self._page([], page)
        books, total, pagecount = self._robust(
            "搜索「%s」" % query,
            lambda: self._search(query, page),
            ([], 0, 1),
        )
        result = self._page(
            [self._card(book) for book in books], page, total, pagecount
        )
        self._log("搜索 kw=%s pg=%s -> %d 条 (total=%s pagecount=%s)"
                  % (query, page, len(result["list"]), total, result["pagecount"]))
        if not result["list"]:
            self._log("警告：搜索为空 kw=%s，last_error=%s"
                      % (query, self._last_error or "无"))
        return result

    # -- 详情 / 播放 --------------------------------------------------------

    def detailContent(self, ids):
        ident = str(ids[0] if ids else "").removeprefix("vod/").strip()
        if not ident:
            return {"list": [], "msg": "无效的影片 ID"}

        # 0) 搜索/分类进来时元数据已有缓存：跳过 view，直接 pagelist 取分P，
        #    既省一次请求也避开 view 接口的高频风控(412)
        cached = self._recall(ident) or {}

        # 1) 无缓存才请求 view；412 只快速重试 1 次就交给 pagelist 回退
        info = None
        if cached:
            self._log("详情 bvid=%s 命中搜索缓存，跳过 view 请求" % ident)
        else:
            try:
                data = self._get_json(
                    "%s?bvid=%s" % (VIEW_URL, quote(ident, safe="")), retries=1
                )
                if isinstance(data.get("data"), dict):
                    info = data["data"]
            except Exception as error:
                self._note_error("详情view", error)
                info = None

        # 2) 分P 目录：view 优先；不可用时回退 pagelist
        pages = list(info.get("pages") or []) if info else []
        if not pages:
            try:
                data = self._get_json(
                    "%s?bvid=%s" % (PAGE_LIST_URL, quote(ident, safe=""))
                )
                plist = data.get("data")
                if isinstance(plist, list):
                    pages = [part for part in plist if isinstance(part, dict)]
            except Exception as error:
                self._note_error("详情pagelist", error)
                pages = []
        if not pages and info:
            pages = [{
                "cid": info.get("cid"),
                "page": 1,
                "part": info.get("title") or "正片",
                "duration": info.get("duration") or 0,
            }]
        if not pages:
            return {"list": [], "msg": "读取分P目录失败（接口繁忙或视频不存在）"}
        if info is None:
            self._log("详情 bvid=%s 走 pagelist 回退，分P=%d（last_error=%s）"
                      % (ident, len(pages), self._last_error or "无"))

        # 3) 元数据：view > 搜索缓存
        bvid = str((info or {}).get("bvid") or cached.get("bvid") or ident)
        owner = str(((info or {}).get("owner") or {}).get("name") or cached.get("author") or "")
        title = _clean_title((info or {}).get("title")) or str(cached.get("name") or "") \
            or ("B站有声 " + bvid)
        pic = _normalize_pic((info or {}).get("pic")) or str(cached.get("pic") or "")
        desc = str((info or {}).get("desc") or cached.get("desc") or "").strip()
        year = _year_of((info or {}).get("pubdate")) or str(cached.get("year") or "")

        total_seconds = _safe_int((info or {}).get("duration"))
        if total_seconds <= 0:
            total_seconds = sum(_safe_int(part.get("duration")) for part in pages)
        remark = "全%d集" % len(pages) if len(pages) > 1 else "单集"
        if total_seconds > 0:
            remark += " · " + _duration_text(total_seconds)

        item = self._card({
            "bvid": bvid,
            "name": title,
            "pic": pic,
            "author": owner,
            "duration_text": _duration_text(total_seconds),
            "year": year,
            "desc": desc,
        })
        item.update({
            "type_name": str((info or {}).get("tname") or "有声小说"),
            "vod_remarks": remark,
            "vod_year": year,
            "vod_content": desc,
        })
        if owner:
            item["vod_actor"] = self._clickable(owner)
            item["vod_director"] = owner

        episodes_main = []
        episodes_backup = []
        for index, part in enumerate(pages, start=1):
            cid = _safe_int(part.get("cid"))
            page_no = _safe_int(part.get("page")) or index
            label = _safe_label(part.get("part") or "第%d集" % page_no)
            if len(pages) > 1 and not str(part.get("part") or "").strip():
                label = "第%d集" % page_no
            episodes_main.append("%s$play/%s/%s/main" % (label, bvid, cid))
            episodes_backup.append("%s$play/%s/%s/backup" % (label, bvid, cid))
        if not episodes_main or episodes_main[0].endswith("/0"):
            return {"list": [], "msg": "该视频没有可播放的分P"}

        item["vod_play_from"] = "高清音频线$$$备用音频线"
        item["vod_play_url"] = "#".join(episodes_main) + "$$$" + "#".join(episodes_backup)
        self._log("详情 bvid=%s title=%s 分P=%d%s"
                  % (bvid, title[:24], len(pages),
                     "（view直连）" if info is not None else "（回退）"))
        return {"list": [item]}

    def playerContent(self, flag, id, vipFlags):
        del flag, vipFlags
        parts = str(id or "").split("/")
        if len(parts) != 4 or parts[0] != "play" or parts[3] not in ("main", "backup"):
            return {"parse": 0, "msg": "无效的播放 ID"}
        bvid, cid, line = parts[1], _safe_int(parts[2]), parts[3]
        if not bvid or cid <= 0:
            return {"parse": 0, "msg": "无效的播放参数"}

        try:
            url = self._resolve_audio_url(bvid, cid, line)
        except Exception as error:
            self._note_error("取流", error)
            return {"parse": 0, "msg": "取流失败：" + type(error).__name__}
        if not url:
            return {"parse": 0, "msg": "该集暂无可用音频流"}

        result = {
            "parse": 0,
            "jx": 0,
            "url": url,
            "header": {
                "User-Agent": USER_AGENT,
                "Referer": HOME + "/",
                "Origin": HOME,
            },
            "format": "audio/mp4",
        }
        self._log("取流 bvid=%s cid=%s line=%s -> host=%s"
                  % (bvid, cid, line, urlsplit(url).netloc))
        return result

    # -- 互动 / 嗅探 --------------------------------------------------------

    def action(self, action):
        self._log("action=%s" % action)
        if action == "debug":
            if self._last_error:
                return {"msg": "最近一次失败：" + self._last_error}
            return {"msg": "暂无错误记录（各接口正常）"}
        if action == "refresh":
            self._reset_session()
            self._search_cache = {}
            try:
                self._ensure_session()
                return {"msg": "已重新预热 B 站会话"}
            except Exception as error:
                self._note_error("重新预热", error)
                return {"msg": "预热失败：" + type(error).__name__}
        if action == "cookie_status":
            if str(self.options.get("cookie") or "").strip():
                return {"msg": "已配置登录 Cookie，可解锁高音质（有效性由站方判定）"}
            return {"msg": "未配置登录 Cookie，当前为游客模式（默认音质）"}
        return {"msg": "不支援此操作"}

    def manualVideoCheck(self):
        return True

    def localProxy(self, param):
        # 本爬虫不使用本机代理（与范例契约一致）。
        return 404

    def isVideoFormat(self, url):
        try:
            parsed = urlsplit(str(url or ""))
        except ValueError:
            return False
        path = parsed.path.lower()
        return (
            parsed.scheme in ("http", "https")
            and bool(parsed.netloc)
            and path.endswith((".m4s", ".m4a", ".mp3", ".mp4", ".aac", ".flac"))
            and "/ad/" not in path
        )

    # -- 内部：会话与请求 ---------------------------------------------------

    def _note_error(self, stage, error):
        """记录最近一次失败（截断查询串，避免签名网址进入 Toast/日志）。"""
        detail = str(error).strip() or type(error).__name__
        detail = detail.split("?")[0]
        self._last_error = ("%s / %s: %s" % (stage, type(error).__name__, detail))[:240]
        self._log("错误 " + self._last_error)

    def _log(self, message):
        """后台日志。只输出阶段/关键词/条数/状态，绝不输出 Cookie、签名或
        完整媒体网址；测试桩没有 log 方法时静默跳过。"""
        log = getattr(self, "log", None)
        if callable(log):
            try:
                log("[阿B听书] " + str(message))
            except Exception:
                pass

    def _reset_session(self):
        """丢弃会话状态（保留 Cookie），下次请求会重新预热。"""
        self._ready = False
        self._img_url = ""
        self._sub_url = ""
        self._mixin = ""

    def _robust(self, stage, func, default):
        """执行网络逻辑；异常时记录错误、重置会话并整体重试一次。"""
        try:
            return func()
        except Exception as error:
            self._note_error(stage, error)
        self._reset_session()
        try:
            return func()
        except Exception as error:
            self._note_error(stage + "/重试", error)
        return default

    def _ensure_session(self):
        """预热：首页种 Cookie（失败不致命）-> nav 取 WBI 密钥；
        nav 不可用时降级到内置备份密钥，保证签名类接口仍可工作。"""
        if self._ready and self._mixin:
            return
        self._log("预热会话开始")
        try:
            self._http(HOME + "/", {"Accept": "text/html,application/xhtml+xml,*/*"})
            self._log("首页预热完成，已合并 Cookie（%d 项）" % len(self._cookies))
        except Exception as error:
            # 非致命：本地已预置 buvid3，nav 仍可拿到 WBI 密钥
            self._note_error("首页预热", error)
        img_url = ""
        sub_url = ""
        try:
            data = self._get_json(NAV_URL, ok_codes=(0, -101), retries=3)
            wbi = ((data.get("data") or {}).get("wbi_img") or {})
            img_url = str(wbi.get("img_url") or "")
            sub_url = str(wbi.get("sub_url") or "")
        except Exception as error:
            self._note_error("取WBI密钥", error)
        if img_url and sub_url:
            self._img_url = img_url
            self._sub_url = sub_url
            self._mixin = _mixin_key(img_url, sub_url)
            self._ready = True
            self._log("会话就绪（WBI 密钥已更新）")
            return
        # 备份密钥降级（参考 B站.py）：不再直接抛错，让搜索/取流继续可用
        self._note_error("取WBI密钥", RuntimeError("nav 未返回 wbi_img"))
        self._img_url = WBI_FALLBACK_IMG
        self._sub_url = WBI_FALLBACK_SUB
        self._mixin = _mixin_key(WBI_FALLBACK_IMG, WBI_FALLBACK_SUB)
        self._ready = True
        self._log("会话就绪（nav 不可用，使用内置备份 WBI 密钥）")

    def _cookie_header(self):
        if not self._cookies:
            return ""
        return "; ".join("%s=%s" % (k, v) for k, v in self._cookies.items())

    def _throttle(self):
        gap = MIN_REQUEST_GAP_MS / 1000.0
        elapsed = time.time() - self._last_request_at
        if 0 < elapsed < gap:
            time.sleep(gap - elapsed)
        self._last_request_at = time.time()

    def _merge_set_cookie(self, response):
        """合并响应中的 Set-Cookie。优先用 requests 已解析的 response.cookies，
        失败时回退读 Set-Cookie 头；都拿不到就保持预置 buvid3。"""
        try:
            jar = getattr(response, "cookies", None)
            if jar is not None:
                for key, value in jar.items():
                    key = str(key).strip()
                    if key:
                        self._cookies[key] = str(value)
                if len(jar) > 0:
                    return
        except Exception:
            pass
        try:
            raw = response.headers.get("Set-Cookie")
        except Exception:
            return
        if not raw:
            return
        first = str(raw).split(";")[0].strip()
        key, sep, value = first.partition("=")
        if sep and key.strip():
            self._cookies[key.strip()] = value.strip()

    def _http(self, url, extra_headers=None):
        """经 base 类的 self.fetch（requests）发 GET，回传 (status_code, text)。"""
        values = {
            "User-Agent": USER_AGENT,
            "Referer": HOME + "/",
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "zh-CN,zh;q=0.9",
        }
        cookie = self._cookie_header()
        if cookie:
            values["Cookie"] = cookie
        if extra_headers:
            values.update(extra_headers)

        self._throttle()
        response = self.fetch(
            str(url),
            headers=values,
            timeout=REQUEST_TIMEOUT_SECONDS,
            verify=True,
        )
        self._merge_set_cookie(response)
        return response.status_code, response.text or ""

    def _get_json(self, url, headers=None, ok_codes=(0,), retries=2):
        """GET 并解析 JSON；-412/-352/403 风控自动退避重试。"""
        last_error = None
        for attempt in range(retries + 1):
            try:
                status, text = self._http(url, headers)
            except Exception as error:
                last_error = error
                time.sleep(0.8 * (attempt + 1))
                continue
            if status in (403, 412, 429):
                last_error = RuntimeError("HTTP %s" % status)
                self._log("风控 HTTP %s，%s 第%d/%d 次退避"
                          % (status, urlsplit(url).path, attempt + 1, retries + 1))
                time.sleep(2.0 * (attempt + 1))
                continue
            if status >= 400:
                raise RuntimeError("HTTP %s" % status)
            try:
                data = json.loads(text)
            except ValueError:
                last_error = RuntimeError("回应不是 JSON")
                time.sleep(0.8 * (attempt + 1))
                continue
            code = data.get("code")
            if code in (-412, -352):
                last_error = RuntimeError("触发风控 %s" % code)
                self._log("风控 code=%s，%s 第%d/%d 次退避"
                          % (code, urlsplit(url).path, attempt + 1, retries + 1))
                time.sleep(1.2 * (attempt + 1))
                continue
            if code in ok_codes:
                return data
            raise RuntimeError("B站接口错误 code=%s" % code)
        if last_error is not None:
            raise last_error
        raise RuntimeError("请求失败")

    # -- 内部：搜索 ---------------------------------------------------------

    def _signed_url(self, base, params):
        self._ensure_session()
        return base + "?" + urlencode(_wbi_sign(params, self._mixin))

    def _search_raw(self, keyword, page, order, stats):
        params = {
            "search_type": "video",
            "keyword": keyword,
            "page": page,
            "page_size": PAGE_SIZE,
            "platform": "pc",
            "web_location": 1430654,
        }
        if order:
            params["order"] = order
        url = self._signed_url(SEARCH_URL, params)
        headers = {
            "Origin": SEARCH_HOME,
            "Referer": "%s/video?keyword=%s" % (SEARCH_HOME, quote(keyword, safe="")),
        }

        for attempt in range(3):
            data = self._get_json(url, headers)
            payload = data.get("data")
            if not isinstance(payload, dict):
                payload = {}
            result = payload.get("result")
            if not isinstance(result, list):
                # v_voucher 极验风控：退避后重签重试（abts 同款 1.5s*次数）
                if attempt < 2:
                    self._log("搜索 kw=%s 触发 v_voucher，第%d/3 次退避重签"
                              % (keyword, attempt + 1))
                    time.sleep(1.5 * (attempt + 1))
                    url = self._signed_url(SEARCH_URL, params)
                    continue
                self._note_error(
                    "搜索「%s」" % keyword,
                    RuntimeError(
                        "风控未恢复" if payload.get("v_voucher") else "响应缺少结果列表"
                    ),
                )
                return []

            num_results = _safe_int(payload.get("numResults"))
            num_pages = _safe_int(payload.get("numPages"))
            if num_results:
                stats["total"] = max(stats.get("total", 0), num_results)
            if num_pages:
                stats["pagecount"] = max(stats.get("pagecount", 0), num_pages)

            books = []
            kept = dropped = 0
            for entry in result:
                if not isinstance(entry, dict):
                    continue
                if not _is_audiobook_item(entry, keyword):
                    dropped += 1
                    continue
                book = self._book_from_search(entry)
                if book:
                    books.append(book)
                    kept += 1
            self._log("搜索 kw=%s pg=%s order=%s -> 原始%d 条，过滤后 %d 条 (total=%s)"
                      % (keyword, page, order or "-", len(result), kept, stats.get("total", 0)))
            return books
        return []

    def _app_search(self, keyword, page):
        """App 端搜索降级。

        网页版搜索被 v_voucher 卡死时调用；App 接口无需 WBI 签名。
        把 App 返回结构转换回网页搜索的同构 entry，复用同一套听书过滤。
        回传 books 列表；失败返回 []（stats 不写入，缓存策略不受影响）。
        """
        params = {
            "build": "2001100",
            "keyword": keyword,
            "mobi_app": "android_hd",
            "platform": "android",
            "pn": page,
            "ps": PAGE_SIZE,
        }
        url = APP_SEARCH_URL + "?" + urlencode(params)
        headers = {"Referer": HOME + "/", "Origin": HOME}
        try:
            data = self._get_json(url, headers)
        except Exception as error:
            self._note_error("App搜索「%s」" % keyword, error)
            return []
        items = ((data.get("data") or {}).get("items") or {}).get("archive") or []
        if not isinstance(items, list) or not items:
            return []

        books = []
        kept = dropped = 0
        for item in items:
            if not isinstance(item, dict):
                continue
            share = item.get("share") or {}
            video = share.get("video") if isinstance(share, dict) else None
            bvid = str((video or {}).get("bvid") or "").strip()
            entry = {
                "bvid": bvid,
                "title": _clean_title(item.get("title")),
                "pic": item.get("cover") or "",
                "author": str(item.get("author") or "").strip(),
                "duration": item.get("duration"),
                "pubdate": item.get("ptime"),
                "description": str(item.get("view_content") or "").strip(),
                "tag": "",
            }
            if not _is_audiobook_item(entry, keyword):
                dropped += 1
                continue
            book = self._book_from_search(entry)
            if book:
                books.append(book)
                kept += 1
        self._log("App搜索降级 kw=%s pg=%s -> 原始%d 条，过滤后 %d 条"
                  % (keyword, page, len(items), kept))
        return books

    def _book_from_search(self, entry):
        bvid = str(entry.get("bvid") or "").strip()
        if not bvid:
            return None
        return {
            "bvid": bvid,
            "name": _clean_title(entry.get("title")),
            "pic": _normalize_pic(entry.get("pic")),
            "author": str(entry.get("author") or "").strip(),
            "duration_text": _duration_text(_parse_duration(entry.get("duration"))),
            "year": _year_of(entry.get("pubdate")),
            "desc": str(entry.get("description") or "").strip(),
        }

    def _search(self, keyword, page, order=None):
        """搜索并过滤为听书内容；命中太少时用「关键词 有声小说」补搜合并。

        结果短暂缓存；连正常响应都没拿到（疑似风控）时换会话整体重试一次。
        回传 (books, total, pagecount)。
        """
        keyword = str(keyword or "").strip()
        if not keyword:
            return [], 0, 1

        cache_key = "%s|%s|%s" % (keyword, page, order or "")
        cached = self._search_cache.get(cache_key)
        if cached and cached[0] > time.time():
            self._log("缓存命中 %s -> %d 条" % (cache_key, len(cached[1][0])))
            return cached[1]
        self._search_cache = {
            key: value for key, value in self._search_cache.items()
            if value[0] > time.time()
        }

        stats = {}
        books = self._search_raw(keyword, page, order, stats)

        # 命中太少就补搜合并（比 abts 更积极：不再因关键词含听书词而跳过，
        # 分类关键词如「玄幻小说听书」补搜后条数显著提升）
        if len(books) < 6:
            extra_keyword = keyword + " 有声小说"
            self._log("命中仅 %d 条，补搜「%s」合并" % (len(books), extra_keyword))
            try:
                extra_stats = {}
                extra = self._search_raw(extra_keyword, page, order, extra_stats)
            except Exception as error:
                self._note_error("补搜", error)
                extra = []
            seen = {book["bvid"] for book in books}
            for book in extra:
                if book["bvid"] not in seen:
                    seen.add(book["bvid"])
                    books.append(book)
            stats["total"] = max(stats.get("total", 0), extra_stats.get("total", 0))
            stats["pagecount"] = max(
                stats.get("pagecount", 0), extra_stats.get("pagecount", 0)
            )

        # 完全没拿到正常响应（多半是风控）：换会话冷却后再试一次
        if not books and not stats.get("total"):
            self._log("无正常响应，重置会话冷却 1.5s 后重试 kw=%s" % keyword)
            self._reset_session()
            time.sleep(1.5)
            stats = {}
            books = self._search_raw(keyword, page, order, stats)

        # 网页搜索仍被 v_voucher 卡死：降级到 App 端搜索接口。
        # App 接口返回结构不同，在此转换回同构 entry 后复用同一套听书过滤。
        if not books and not stats.get("total"):
            books = self._app_search(keyword, page)

        total = stats.get("total", 0)
        pagecount = stats.get("pagecount", 0)
        if not pagecount:
            pagecount = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE) if total else (
                page if books else 1
            )
        pagecount = max(1, pagecount)
        if total:  # 只缓存拿到了正常响应的结果，风控空结果不缓存
            self._search_cache[cache_key] = (
                time.time() + SEARCH_CACHE_TTL, (books, total, pagecount)
            )
        return books, total, pagecount

    # -- 内部：取流 ---------------------------------------------------------

    @staticmethod
    def _track_url(track):
        if not isinstance(track, dict):
            return ""
        return str(track.get("baseUrl") or track.get("base_url") or "")

    def _resolve_audio_url(self, bvid, cid, line):
        params = {
            "bvid": bvid,
            "cid": cid,
            "qn": 80,
            "fnval": 4048,
            "fnver": 0,
            "fourk": 1,
            "try_look": 1,
            "gaia_source": "prefer-ua",
        }
        url = self._signed_url(PLAY_URL, params)
        data = self._get_json(url)
        stream = data.get("data")
        if not isinstance(stream, dict):
            return ""

        dash = stream.get("dash")
        if isinstance(dash, dict):
            tracks = [
                track for track in (dash.get("audio") or [])
                if isinstance(track, dict)
            ]
            tracks.sort(
                key=lambda track: _safe_int(track.get("bandwidth")), reverse=True
            )
            flac = (dash.get("flac") or {}).get("audio") \
                if isinstance(dash.get("flac"), dict) else None
            dolby_list = (dash.get("dolby") or {}).get("audio") \
                if isinstance(dash.get("dolby"), dict) else None
            dolby = dolby_list[0] if isinstance(dolby_list, list) and dolby_list else None

            if line == "main":
                for candidate in (flac, dolby):
                    candidate_url = self._track_url(candidate)
                    if candidate_url:
                        return candidate_url
                if tracks:
                    track = tracks[0]
                    return self._track_url(track) or (
                        str((track.get("backup_url") or [""])[0])
                    )
            else:
                if len(tracks) > 1:
                    track = tracks[1]
                    backup = track.get("backup_url") or []
                    if backup:
                        return str(backup[0])
                    track_url = self._track_url(track)
                    if track_url:
                        return track_url
                if tracks:
                    backup = tracks[0].get("backup_url") or []
                    if backup:
                        return str(backup[0])
                    fallback = self._track_url(flac) or self._track_url(dolby)
                    if fallback:
                        return fallback
                    return self._track_url(tracks[0])

        # 无 DASH 时回退单流（durl）
        durl = stream.get("durl")
        if isinstance(durl, list) and durl:
            first = durl[0]
            if isinstance(first, dict):
                fallback_url = str(first.get("url") or "")
                if line == "backup":
                    backup = first.get("backup_url") or []
                    if backup:
                        return str(backup[0])
                return fallback_url
        return ""

    # -- 内部：卡片与分页 ---------------------------------------------------

    def _remember(self, book):
        """把搜索/详情见到的书籍元数据留在内存，供 view 被风控时回退。
        不存占位数据（无封面的兜底标题），避免污染后续详情。"""
        bvid = str(book.get("bvid") or "")
        name = str(book.get("name") or "")
        if not bvid:
            return
        if not book.get("pic") and name.startswith("B站有声 "):
            return
        if len(self._book_cache) >= 300:
            for oldest in list(self._book_cache)[:50]:
                self._book_cache.pop(oldest, None)
        self._book_cache[bvid] = dict(book)

    def _recall(self, bvid):
        cached = self._book_cache.get(str(bvid))
        return dict(cached) if cached else None

    @staticmethod
    def _page_number(pg):
        try:
            return max(1, int(pg))
        except (TypeError, ValueError):
            return 1

    @staticmethod
    def _page(items, page, total=None, pagecount=None):
        if pagecount is None:
            if not items:
                pagecount = 1
            elif total:
                pagecount = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
            else:
                pagecount = page
        if total is None:
            total = (page - 1) * PAGE_SIZE + len(items) if items else 0
        if not items and page > 1:
            pagecount = 1
        return {
            "list": items,
            "page": page,
            "pagecount": max(1, pagecount),
            "limit": PAGE_SIZE,
            "total": total,
        }

    @staticmethod
    def _card_style():
        # B 站封面为横版 170:106，rect 1.6 不拉伸
        return {"type": "rect", "ratio": 1.6}

    def _card(self, book):
        self._remember(book)
        remarks = []
        if book.get("author"):
            remarks.append(book["author"])
        if book.get("duration_text"):
            remarks.append(book["duration_text"])
        return {
            "vod_id": "vod/" + book["bvid"],
            "vod_name": book["name"],
            "vod_pic": book.get("pic") or "",
            "vod_remarks": " · ".join(remarks),
            "vod_year": book.get("year") or "",
            "style": self._card_style(),
        }

    @staticmethod
    def _folder_card(host):
        name, works, keyword = host
        return {
            "vod_id": "kw/" + quote(keyword, safe=""),
            "vod_name": name,
            "vod_remarks": works,
            "vod_tag": "folder",
        }

    @staticmethod
    def _tool_cards():
        return [
            {
                "vod_id": "action/" + action,
                "vod_name": name,
                "vod_remarks": remark,
                "action": action,
                "style": {"type": "list"},
            }
            for action, name, remark in (
                ("debug", "查看最近错误", "Toast 显示上次失败原因"),
                ("refresh", "重新预热会话", "重建 Cookie 与 WBI 密钥"),
                ("cookie_status", "查看登录状态", "是否配置了登录 Cookie"),
            )
        ]

    @staticmethod
    def _clickable(name):
        ident = "kw/" + quote(str(name), safe="")
        payload = json.dumps(
            {"id": ident, "name": name, "type_flag": "1"},
            ensure_ascii=False,
            separators=(",", ":"),
        )
        return "[a=cr:%s/]%s[/a]" % (payload, name)
