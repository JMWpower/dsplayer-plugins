/*
@header({
  title: '喜福短剧',
  lang: 'dr3',
  searchable: 2, filterable: 1, quickSearch: 0,
})

【喜福短剧 · drpy3 JS 源】（对应 Python 版已验证逻辑移植）
- 两级分类：一级 9 类走服务端过滤；二级标签（战神/总裁/穿越等）服务端不支持单独过滤，
  采用「拉取一级分类全量 + 本地按剧集标签过滤 + 本地分页」，带 10 分钟内存缓存。
- 搜索：站方 API 无独立搜索端点，list 接口 search 参数无效，改为本地全量匹配
  （标题/别名/主演），与 Python 版一致。
- 详情：drama/detail 真实 episodeList（含 sequence/vid）生成播放列表，不硬造集数。
- 播放：play_auth -> playAuth(base64 JSON 凭证) -> 阿里云 VOD HMAC-SHA1 签名请求
  -> 真实 mp4 直链，清晰度按 OD > FHD > HD > SD 择优。
- 本文件自包含 base64 / UTF-8 / HMAC-SHA1 纯 JS 实现，不依赖运行时 crypto。
*/

const API_HOST = 'https://minidrama-api.contentchina.com';
const WEB_HOST = 'https://minidrama.contentchina.com';
const PAGE_SIZE = 24;
const FETCH_BATCH = 100;
const CACHE_TTL = 600;          // 秒
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0';

const DEFAULT_HEADERS = {
    'Accept': '*/*',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Origin': WEB_HOST,
    'Referer': WEB_HOST + '/',
    'User-Agent': UA,
};

// ═══════════════════════ 自包含工具：base64 / UTF-8 / HMAC-SHA1 ═══════════════════════

const B64C = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

function b64DecodeToBytes(s) {
    s = String(s || '').replace(/=+$/, '').trim();
    const out = [];
    let buf = 0, bits = 0;
    for (let i = 0; i < s.length; i++) {
        const v = B64C.indexOf(s.charAt(i));
        if (v < 0) continue;
        buf = (buf << 6) | v;
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push((buf >> bits) & 0xff);
            buf &= (1 << bits) - 1 || 0;
            if (bits === 0) buf = 0;
        }
    }
    return out;
}

function bytesToUtf8(bytes) {
    let s = '';
    let i = 0;
    while (i < bytes.length) {
        const b = bytes[i++];
        if (b < 0x80) s += String.fromCharCode(b);
        else if (b < 0xe0) s += String.fromCharCode(((b & 0x1f) << 6) | (bytes[i++] & 0x3f));
        else if (b < 0xf0) {
            const cp = ((b & 0x0f) << 12) | ((bytes[i++] & 0x3f) << 6) | (bytes[i++] & 0x3f);
            s += String.fromCharCode(cp);
        } else {
            const cp = ((b & 0x07) << 18) | ((bytes[i++] & 0x3f) << 12) |
                ((bytes[i++] & 0x3f) << 6) | (bytes[i++] & 0x3f);
            s += String.fromCharCode(0xd800 + ((cp - 0x10000) >> 10), 0xdc00 + ((cp - 0x10000) & 0x3ff));
        }
    }
    return s;
}

function utf8Encode(s) {
    const out = [];
    for (let i = 0; i < s.length; i++) {
        let cp = s.codePointAt(i);
        if (cp > 0xffff) i++;
        if (cp < 0x80) out.push(cp);
        else if (cp < 0x800) {
            out.push(0xc0 | (cp >> 6), 0x80 | (cp & 0x3f));
        } else if (cp < 0x10000) {
            out.push(0xe0 | (cp >> 12), 0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
        } else {
            out.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3f),
                0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
        }
    }
    return out;
}

function b64EncodeBytes(bytes) {
    let out = '';
    for (let i = 0; i < bytes.length; i += 3) {
        const b0 = bytes[i];
        const b1 = i + 1 < bytes.length ? bytes[i + 1] : 0;
        const b2 = i + 2 < bytes.length ? bytes[i + 2] : 0;
        out += B64C.charAt(b0 >> 2);
        out += B64C.charAt(((b0 & 3) << 4) | (b1 >> 4));
        out += i + 1 < bytes.length ? B64C.charAt(((b1 & 15) << 2) | (b2 >> 6)) : '=';
        out += i + 2 < bytes.length ? B64C.charAt(b2 & 63) : '=';
    }
    return out;
}

function sha1Bytes(msgBytes) {
    const ml = msgBytes.length;
    const withLen = ml + 1 + 8;
    const padLen = (withLen % 64 === 0) ? withLen : withLen + (64 - (withLen % 64));
    const buf = new Array(padLen).fill(0);
    for (let i = 0; i < ml; i++) buf[i] = msgBytes[i];
    buf[ml] = 0x80;
    const bitLen = ml * 8;
    const hi = Math.floor(bitLen / 0x100000000), lo = bitLen >>> 0;
    buf[padLen - 8] = (hi >>> 24) & 0xff; buf[padLen - 7] = (hi >>> 16) & 0xff;
    buf[padLen - 6] = (hi >>> 8) & 0xff;  buf[padLen - 5] = hi & 0xff;
    buf[padLen - 4] = (lo >>> 24) & 0xff; buf[padLen - 3] = (lo >>> 16) & 0xff;
    buf[padLen - 2] = (lo >>> 8) & 0xff;  buf[padLen - 1] = lo & 0xff;

    let h0 = 0x67452301, h1 = 0xefcdab89, h2 = 0x98badcfe, h3 = 0x10325476, h4 = 0xc3d2e1f0;
    const w = new Array(80);
    for (let off = 0; off < padLen; off += 64) {
        for (let i = 0; i < 16; i++) {
            w[i] = ((buf[off + i * 4] << 24) | (buf[off + i * 4 + 1] << 16) |
                (buf[off + i * 4 + 2] << 8) | buf[off + i * 4 + 3]) >>> 0;
        }
        for (let i = 16; i < 80; i++) {
            w[i] = ((w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]) << 1 |
                (w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16]) >>> 31) >>> 0;
        }
        let a = h0, b = h1, c = h2, d = h3, e = h4;
        for (let i = 0; i < 80; i++) {
            let f, k;
            if (i < 20) { f = (b & c) | (~b & d); k = 0x5a827999; }
            else if (i < 40) { f = b ^ c ^ d; k = 0x6ed9eba1; }
            else if (i < 60) { f = (b & c) | (b & d) | (c & d); k = 0x8f1bbcdc; }
            else { f = b ^ c ^ d; k = 0xca62c1d6; }
            const tmp = (((a << 5) | (a >>> 27)) + f + e + k + w[i]) >>> 0;
            e = d; d = c; c = ((b << 30) | (b >>> 2)) >>> 0; b = a; a = tmp;
        }
        h0 = (h0 + a) >>> 0; h1 = (h1 + b) >>> 0; h2 = (h2 + c) >>> 0;
        h3 = (h3 + d) >>> 0; h4 = (h4 + e) >>> 0;
    }
    const out = [];
    for (const h of [h0, h1, h2, h3, h4]) {
        out.push((h >>> 24) & 0xff, (h >>> 16) & 0xff, (h >>> 8) & 0xff, h & 0xff);
    }
    return out;
}

function hmacSha1Base64(keyStr, msgStr) {
    const keyBytes = utf8Encode(keyStr);
    if (keyBytes.length > 64) {
        const hashed = sha1Bytes(keyBytes);
        keyBytes.length = 0;
        keyBytes.push(...hashed);
    }
    const ipad = new Array(64).fill(0x36);
    const opad = new Array(64).fill(0x5c);
    for (let i = 0; i < keyBytes.length; i++) {
        ipad[i] = ipad[i] ^ keyBytes[i];
        opad[i] = opad[i] ^ keyBytes[i];
    }
    const inner = sha1Bytes(ipad.concat(utf8Encode(msgStr)));
    const outer = sha1Bytes(opad.concat(inner));
    return b64EncodeBytes(outer);
}

// RFC3986 编码（encodeURIComponent 之外补 !'()*）
function quote(s) {
    return encodeURIComponent(String(s)).replace(/[!'()*]/g, c =>
        '%' + c.charCodeAt(0).toString(16).toUpperCase());
}

function b64json(s) {
    try {
        return JSON.parse(bytesToUtf8(b64DecodeToBytes(s)));
    } catch (e) {
        return null;
    }
}

// ═══════════════════════ 内存缓存（模块级，进程内共享） ═══════════════════════

let _cache = { ts: 0, items: null, cats: null };
let _cidCache = {};   // cid -> { ts, items }

function fresh(ts) {
    return (Date.now() - ts) / 1000 < CACHE_TTL;
}

// ═══════════════════════ 网络工具 ═══════════════════════

async function apiGet(ctx, apiPath, params) {
    const query = params
        ? Object.keys(params).map(k => k + '=' + encodeURIComponent(params[k])).join('&')
        : '';
    const url = API_HOST + apiPath + (query ? '?' + query : '');
    const res = await ctx.lib.net.request(url, { headers: DEFAULT_HEADERS });
    return JSON.parse(res.content);
}

// 拉取全站 / 指定一级分类全部剧集（自动翻页）
async function fetchAllItems(ctx, cid) {
    const now = Date.now();
    if (cid) {
        const hit = _cidCache[cid];
        if (hit && fresh(hit.ts)) return hit.items;
    } else if (_cache.items && fresh(_cache.ts)) {
        return _cache.items;
    }
    const items = [];
    let page = 1;
    for (;;) {
        const params = { pageSize: FETCH_BATCH, currentPage: page };
        if (cid) params['filterCategories[]'] = cid;
        const data = await apiGet(ctx, '/web/v1/drama/list', params);
        if (!data || data.code !== 200) break;
        const pd = data.data || {};
        const batch = pd.data || [];
        items.push(...batch);
        const pg = pd.pagination || {};
        if (page >= (pg.totalPages || 1) || !batch.length) break;
        page++;
    }
    if (cid) _cidCache[cid] = { ts: now, items };
    else _cache = { ts: now, items, cats: _cache.cats };
    return items;
}

async function fetchMainCategories(ctx) {
    if (_cache.cats && fresh(_cache.cats._ts)) return _cache.cats.list;
    const data = await apiGet(ctx, '/web/v1/home/categoryList');
    const list = ((data && data.data && data.data.categories) || []).map(c => ({
        type_id: String(c.id),
        type_name: String(c.name),
    }));
    _cache.cats = { _ts: Date.now(), list };
    return list;
}

async function findAlbum(ctx, albumId) {
    const items = await fetchAllItems(ctx, null);
    for (const it of (items || [])) {
        if (String(it.albumId) === String(albumId)) return it;
    }
    return null;
}

function toVideoItem(vod) {
    return {
        vod_id: String(vod.albumId) + '@' + (vod.total || 0),
        vod_name: vod.title || '',
        vod_pic: vod.coverUrl || '',
        vod_remarks: '共' + (vod.total || '?') + '集',
    };
}

// ═══════════════════════ 阿里云 VOD 签名播放 ═══════════════════════

function buildSignParams(cred, videoId) {
    const params = {
        Action: 'GetPlayInfo',
        Version: '2017-03-21',
        Format: 'JSON',
        AccessKeyId: cred.AccessKeyId || '',
        SecurityToken: cred.SecurityToken || '',
        VideoId: videoId,
        AuthInfo: cred.AuthInfo || '',
        Timestamp: new Date().toISOString().replace(/\.\d+Z$/, 'Z'),
        SignatureMethod: 'HMAC-SHA1',
        SignatureVersion: '1.0',
        SignatureNonce: uuid(),
    };
    if (cred.PlayConfig) params.PlayConfig = JSON.stringify(cred.PlayConfig);
    return params;
}

function uuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    });
}

// 构造签名后的 GetPlayInfo 请求 URL
function buildSignedUrl(cred, videoId) {
    const params = buildSignParams(cred, videoId);
    const sortedKeys = Object.keys(params).sort();
    const canon = sortedKeys.map(k => quote(k) + '=' + quote(params[k])).join('&');
    const stringToSign = 'GET&%2F&' + quote(canon);
    const key = (cred.AccessKeySecret || '') + '&';
    const signature = hmacSha1Base64(key, stringToSign);
    const region = cred.Region || 'cn-shanghai';
    return 'https://vod.' + region + '.aliyuncs.com/?' + canon + '&Signature=' + quote(signature);
}

function pickBestPlay(playInfos) {
    if (!playInfos || !playInfos.length) return null;
    const prefer = ['OD', 'FHD', 'HD', 'SD'];
    for (const level of prefer) {
        for (const item of playInfos) {
            if (String(item.Definition || '').toUpperCase() === level && item.PlayURL) {
                return item.PlayURL;
            }
        }
    }
    for (let i = playInfos.length - 1; i >= 0; i--) {
        if (playInfos[i].PlayURL) return playInfos[i].PlayURL;
    }
    return playInfos[0].PlayURL;
}

async function resolvePlayURL(ctx, cred, videoId) {
    const url = buildSignedUrl(cred, videoId);
    const res = await ctx.lib.net.request(url, { headers: DEFAULT_HEADERS });
    let data;
    try {
        data = JSON.parse(res.content);
    } catch (e) {
        return null;
    }
    const infos = (data && data.PlayInfoList && data.PlayInfoList.PlayInfo) || [];
    return pickBestPlay(infos);
}

// ═══════════════════════ 源定义 ═══════════════════════

export default {
    meta: {
        title: '喜福短剧',
        host: API_HOST,
        searchable: 2, filterable: 1, quickSearch: 0, multi: 1,
    },
    rule: {
        headers: DEFAULT_HEADERS,
        timeout: 10000,
    },

    // 首页：9 个一级分类 + 动态子分类（一级分类 x 二级标签）
    async home(ctx, filter) {
        const mainCats = await fetchMainCategories(ctx);
        const items = await fetchAllItems(ctx, null) || [];
        const mainIds = new Set(mainCats.map(c => c.type_id));

        const stat = {};   // '主id|标签id' -> [count, tagName]
        for (const it of items) {
            const cds = it.categoryData || [];
            const mains = cds.map(cd => String(cd.categoryId)).filter(id => mainIds.has(id));
            if (!mains.length) continue;
            for (const cd of cds) {
                const cid = String(cd.categoryId);
                const cname = String(cd.categoryName || '');
                if (mainIds.has(cid)) continue;
                for (const m of mains) {
                    const k = m + '|' + cid;
                    if (!stat[k]) stat[k] = [0, cname];
                    stat[k][0]++;
                }
            }
        }

        const grouped = {};
        for (const k of Object.keys(stat)) {
            if (stat[k][0] < 3) continue;
            const p = k.split('|');
            (grouped[p[0]] = grouped[p[0]] || []).push([stat[k][0], p[1], stat[k][1]]);
        }

        const classList = mainCats.map(c => ({ type_id: c.type_id, type_name: c.type_name }));
        for (const c of mainCats) {
            const subs = (grouped[c.type_id] || []).sort((a, b) => b[0] - a[0]).slice(0, 5);
            for (const sub of subs) {
                classList.push({
                    type_id: c.type_id + '$' + sub[1],
                    type_name: c.type_name + '·' + sub[2],
                });
            }
        }
        return { class: classList };
    },

    // 分类列表：一级走服务端分页；子分类（主$标签）本地过滤分页
    async category(ctx, tid, pg, filter, extend) {
        let page = parseInt(pg, 10) || 1;
        if (page < 1) page = 1;

        if (String(tid).indexOf('$') !== -1) {
            const parts = String(tid).split('$');
            const mainId = parts[0], tagId = parts[1];
            const items = await fetchAllItems(ctx, mainId) || [];
            const matched = items.filter(it =>
                (it.categoryData || []).some(cd => String(cd.categoryId) === tagId));
            const total = matched.length;
            const pagecount = Math.max(1, Math.ceil(total / PAGE_SIZE));
            const start = (page - 1) * PAGE_SIZE;
            const chunk = start < total ? matched.slice(start, start + PAGE_SIZE) : [];
            return {
                list: chunk.map(toVideoItem),
                page, pagecount, limit: PAGE_SIZE, total,
            };
        }

        const params = { pageSize: PAGE_SIZE, currentPage: page };
        if (tid) params['filterCategories[]'] = tid;
        const data = await apiGet(ctx, '/web/v1/drama/list', params);
        const pd = (data && data.data) || {};
        const pgd = pd.pagination || {};
        return {
            list: (pd.data || []).map(toVideoItem),
            page,
            pagecount: pgd.totalPages || 1,
            limit: PAGE_SIZE,
            total: pgd.total || 0,
        };
    },

    // 详情：真实分集 + 剧集信息
    async detail(ctx, id) {
        const albumId = String(id).split('@')[0];
        const data = await apiGet(ctx, '/web/v1/drama/detail', { albumId });
        const els = ((data && data.data && data.data.episodeList) || []).filter(e => e.sequence);
        const album = await findAlbum(ctx, albumId) || {};

        let playItems = els.map(e => e.sequence + '$' + albumId + '@' + e.sequence);
        if (!playItems.length) {
            const total = album.total || 0;
            for (let i = 1; i <= total; i++) playItems.push(i + '$' + albumId + '@' + i);
        }

        const actor = album.leadActor;
        const vod = {
            vod_id: id,
            vod_name: album.title || '',
            vod_pic: album.coverUrl || '',
            vod_actor: Array.isArray(actor) ? actor.join(',') : String(actor || ''),
            vod_content: album.introduction || '',
            vod_remarks: '共' + (els.length || album.total || 0) + '集',
            vod_play_from: '喜福专线',
            vod_play_url: playItems.join('#'),
        };
        return { list: [vod] };
    },

    // 搜索：本地全量匹配（标题/别名/主演）
    async search(ctx, wd, quick, pg) {
        let page = parseInt(pg, 10) || 1;
        if (page < 1) page = 1;
        const kw = String(wd || '').trim().toLowerCase();
        if (!kw) return { list: [] };
        const items = await fetchAllItems(ctx, null) || [];
        const matched = items.filter(it => {
            const title = String(it.title || '').toLowerCase();
            const alias = String(it.alias || '').toLowerCase();
            const actor = (Array.isArray(it.leadActor) ? it.leadActor.join('') :
                String(it.leadActor || '')).toLowerCase();
            return title.indexOf(kw) !== -1 || alias.indexOf(kw) !== -1 || actor.indexOf(kw) !== -1;
        });
        const total = matched.length;
        const pagecount = Math.max(1, Math.ceil(total / PAGE_SIZE));
        const start = (page - 1) * PAGE_SIZE;
        const chunk = start < total ? matched.slice(start, start + PAGE_SIZE) : [];
        return {
            list: chunk.map(toVideoItem),
            page, pagecount, limit: PAGE_SIZE, total,
        };
    },

    // 播放：play_auth + 阿里云签名 -> 直链 mp4
    async play(ctx, flag, id, flags, vipFlags) {
        const head = Object.assign({}, DEFAULT_HEADERS);
        const parts = String(id).split('@');
        if (parts.length !== 2) return { parse: 0, url: '', header: head };
        // id 常规为播放器传入的 albumId@seq；兼容完整播放项 seq$albumId@seq
        const albumId = parts[0].split('$').pop();
        const seq = parts[1];

        const auth = await apiGet(ctx, '/web/v1/drama/play_auth', { albumId, seq });
        if (!auth || auth.code !== 200 || !auth.data) return { parse: 0, url: '', header: head };

        const cred = b64json(auth.data.playAuth);
        if (!cred) return { parse: 0, url: '', header: head };

        const videoId = (auth.data.vid) || (cred.VideoMeta && cred.VideoMeta.VideoId);
        if (!videoId) return { parse: 0, url: '', header: head };

        const url = await resolvePlayURL(ctx, cred, videoId);
        return { parse: 0, playUrl: '', url: url || '', header: head };
    },
};