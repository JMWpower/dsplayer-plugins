/*
@header({
  title: '奇奇影视[官]',
  lang: 'dr3',
  searchable: 1, filterable: 1, quickSearch: 0,
})

【奇奇影视｜爱奇艺官方 · DR3 · v4】
- v4: 加入全部子分类（类型/地区/年份/排序），9个一级分类各配独立筛选项
*/

const HOST = 'https://www.iqiyi.com';
const UA = 'Mozilla/5.0 (Linux; Android 12; Pixel 7 Build/SQ3A.220705.003; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/104.0.5112.97 Mobile Safari/537.36';
const PC_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

const CATEGORIES = [
  { type_id: '2', type_name: '电视剧' },
  { type_id: '35', type_name: '短剧' },
  { type_id: '1', type_name: '电影' },
  { type_id: '6', type_name: '综艺' },
  { type_id: '15', type_name: '少儿' },
  { type_id: '4', type_name: '动漫' },
  { type_id: '37', type_name: '漫剧' },
  { type_id: '3', type_name: '纪录片' },
  { type_id: '31', type_name: '知识' },
];

// 子分类：类型、地区、年份、排序
const CLASS_TAGS = {
  '2':  ['古装','都市','悬疑','青春','家庭','罪案','军旅','传奇','武侠','奇幻','历史','谍战','职场','喜剧','偶像','言情'],
  '35': ['甜宠','霸总','重生','复仇','逆袭','萌宝','古装','都市','悬疑','职场','喜剧','穿越','先婚后爱','闪婚','契约'],
  '1':  ['剧情','爱情','喜剧','动作','惊悚','恐怖','科幻','动画','悬疑','犯罪','冒险','奇幻','战争','歌舞','传记','纪录'],
  '6':  ['真人秀','脱口秀','选秀','情感','访谈','音乐','晚会','搞笑','游戏','时尚','运动','亲子','文化','美食','旅行'],
  '15': ['动画','益智','儿歌','童话','冒险','科幻','奇幻','亲子','早教','故事','科普','国学','英语','数学','自然'],
  '4':  ['热血','恋爱','校园','搞笑','奇幻','科幻','冒险','悬疑','治愈','竞技','历史','机战','运动','神魔','穿越','后宫'],
  '37': ['古风','现代','恋爱','悬疑','复仇','穿越','重生','仙侠','都市','校园','奇幻','权谋','甜宠','虐恋','宫斗'],
  '3':  ['历史','自然','人文','社会','科技','探险','军事','经济','政治','艺术','美食','旅行','动物','宇宙','考古','医学'],
  '31': ['历史','文学','哲学','科学','经济','管理','心理','法律','教育','医学','艺术','军事','地理','政治','语言','数学'],
};

const AREA_TAGS = {
  '2':  ['内地','香港','台湾','韩国','美国','日本','英国','泰国','印度','其它'],
  '35': ['内地','韩国'],
  '1':  ['内地','香港','台湾','美国','韩国','日本','英国','法国','德国','泰国','印度','其它'],
  '6':  ['内地','港台','日韩','欧美'],
  '15': ['内地','欧美','日韩'],
  '4':  ['内地','日本','欧美','韩国'],
  '37': ['内地','韩国'],
  '3':  ['内地','欧美','日本','韩国','其它'],
  '31': ['内地','欧美','日韩','其它'],
};

const YEAR_OPTIONS = [2026,2025,2024,2023,2022,2021,2020,2019,2018,2017,2016,2015,2014,2013,2012,2011,2010,2009,2008,2007,2006,2005,2004];

const SORT_OPTIONS = [
  { n: '最新', v: '24' },
  { n: '最热', v: '4' },
  { n: '好评', v: '11' },
];

// ========== 工具函数（百忙无果风格）==========
function getContent(res) {
  if (typeof res === 'string') return res;
  if (res && typeof res === 'object') {
    return res.content || res.body || res.text || res.data || '';
  }
  return '';
}

function parseJson(res) {
  const text = getContent(res);
  try { return JSON.parse(text); } catch (e) { return null; }
}

function listUrl(tid, page, fl) {
  fl = fl || {};
  const useVideoList = (tid === '1' || tid === '4');
  const base = useVideoList
    ? 'https://pcw-api.iqiyi.com/search/video/videolists'
    : 'https://pcw-api.iqiyi.com/search/recommend/list';
  const params = { channel_id: tid, data_type: '1' };
  if (useVideoList) {
    params.pageNum = String(page);
    params.pageSize = '24';
  } else {
    params.page_id = String(page);
    params.ret_num = '24';
  }
  if (fl.mode) params.mode = fl.mode;
  if (fl.year) params.market_release_date_level = fl.year;
  if (fl.region) params.three_category_id = fl.region;
  const qs = Object.keys(params).sort().map(function(k) {
    return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]);
  }).join('&');
  return base + '?' + qs;
}

function parseItem(data) {
  const vid = data.albumId || data.tvId;
  if (!vid) return null;
  const cid = data.channelId;
  let desc = '';
  if (cid === 1) {
    desc = (data.score ? data.score + '分\t' : '') + (data.duration || '');
  } else if ([2, 4, 35, 15, 37].indexOf(cid) >= 0) {
    if (data.latestOrder === data.videoCount) {
      desc = (data.score ? data.score + '分\t' : '') + data.latestOrder + '集全';
    } else if (data.videoCount) {
      desc = (data.score ? data.score + '分\t' : '') + data.latestOrder + '/' + data.videoCount + '集';
    } else if (data.latestOrder) {
      desc = '更新至 ' + data.latestOrder + '集';
    } else {
      desc = data.focus || '';
    }
  } else if (cid === 6) {
    desc = (data.period || '') + '期';
  } else {
    desc = data.focus || '';
  }
  let pic = data.imageUrl || '';
  if (pic) pic = pic.replace('.jpg', '_390_520.jpg?caplist=jpg,webp');
  return {
    vod_id: String(vid),
    vod_name: data.name || data.title || '',
    vod_pic: pic,
    vod_remarks: desc,
    type_name: (data.categories || []).map(function(c) {
      return typeof c === 'string' ? c : (c.name || '');
    }).filter(Boolean).join(','),
  };
}

function searchUrl(keyword, page) {
  return 'https://search.video.iqiyi.com/o?if=html5&key=' + encodeURIComponent(keyword) + '&pageNum=' + page + '&pos=1&pageSize=24&site=iqiyi';
}

function detailUrl(albumId) {
  return 'https://pcw-api.iqiyi.com/video/video/videoinfowithuser/' + albumId + '?agent_type=1&authcookie=&subkey=' + albumId + '&subscribe=1';
}

async function getEps(albumId, channelId, info, request, headers) {
  const eps = [];
  if (channelId === 1) {
    eps.push({ title: info.name || '正片', url: info.playUrl || info.url || info.firstVideoUrl || '' });
  } else if (channelId === 6) {
    try {
      const qs = (info.period || '').split('-')[0];
      const res = await request('https://pcw-api.iqiyi.com/album/source/svlistinfo?cid=6&sourceid=' + albumId + '&timelist=' + qs, { headers });
      const d = parseJson(res);
      const list = ((d && d.data) || {})[qs] || [];
      list.forEach(function(it) { eps.push({ title: it.shortTitle || it.name || '', url: it.playUrl || '' }); });
    } catch (e) {}
  } else {
    try {
      let page = 1;
      let total = 999;
      do {
        const res = await request('https://pcw-api.iqiyi.com/albums/album/avlistinfo?aid=' + albumId + '&size=200&page=' + page, { headers });
        const d = parseJson(res);
        const data = (d && d.data) || {};
        if (page === 1) total = data.total || 0;
        const list = data.epsodelist || [];
        list.forEach(function(it) { eps.push({ title: it.shortTitle || ('第' + it.order + '集'), url: it.playUrl || '' }); });
        page++;
      } while (eps.length < total && page <= 10);
    } catch (e) {}
  }
  return eps;
}

// ========== 导出（百忙无果格式）==========
export default {
  meta: {
    title: '奇奇影视[官]',
    host: 'https://www.iqiyi.com',
    searchable: 1, filterable: 1, quickSearch: 0, multi: 1,
  },

  rule: {
    title: '奇奇影视[官]',
    host: HOST,
    headers: { 'User-Agent': UA },
    timeout: 10000,
    play_parse: true,
    class_name: '电视剧&短剧&电影&综艺&少儿&动漫&漫剧&纪录片&知识',
    class_url: '2&35&1&6&15&4&37&3&31',
  },

  home(ctx, filter) {
    const filters = {};
    for (const c of CATEGORIES) {
      const classTags = CLASS_TAGS[c.type_id] || [];
      const areaTags = AREA_TAGS[c.type_id] || [];
      filters[c.type_id] = [{
        key: 'class', name: '类型',
        value: [{ n: '全部', v: '' }].concat(classTags.map(function(t) { return { n: t, v: t }; })),
      }, {
        key: 'region', name: '地区',
        value: [{ n: '全部', v: '' }].concat(areaTags.map(function(t) { return { n: t, v: t }; })),
      }, {
        key: 'year', name: '年份',
        value: [{ n: '全部', v: '' }].concat(YEAR_OPTIONS.map(function(y) { return { n: String(y), v: String(y) }; })),
      }, {
        key: 'mode', name: '排序',
        value: SORT_OPTIONS.slice(),
      }];
    }
    return { class: CATEGORIES, filters };
  },

  async homeVideoContent(ctx) {
    const { request } = ctx.lib.net;
    const headers = { 'User-Agent': UA, 'Accept': 'application/json' };
    const srcs = ['2', '35', '1'];
    const all = [];
    for (const tid of srcs) {
      try {
        const url = listUrl(tid, 1, {});
        const res = await request(url, { headers });
        let d = parseJson(res);
        if (!d || d.code === 'A00003') {
          const res2 = await request(url, { headers: { 'User-Agent': PC_UA, 'Accept': 'application/json' } });
          d = parseJson(res2);
        }
        const list = ((d && d.data && d.data.list) || []).map(parseItem).filter(Boolean);
        for (const v of list) { if (all.length < 24) all.push(v); }
      } catch (e) {}
      if (all.length >= 24) break;
    }
    return { list: all };
  },

  async category(ctx, tid, pg, filter, extend) {
    tid = String(tid || '');
    const page = Math.max(1, parseInt(pg) || 1);
    const { request } = ctx.lib.net;
    const headers = { 'User-Agent': UA, 'Accept': 'application/json' };

    const url = listUrl(tid, page, extend || {});
    const res = await request(url, { headers });
    let d = parseJson(res);

    if (!d || d.code === 'A00003') {
      const res2 = await request(url, { headers: { 'User-Agent': PC_UA, 'Accept': 'application/json' } });
      d = parseJson(res2);
    }

    const list = ((d && d.data && d.data.list) || []).map(parseItem).filter(Boolean);
    const hasNext = (d && d.data && d.data.has_next === 1) || list.length >= 24;

    return {
      list: list,
      page: page,
      pagecount: hasNext ? page + 1 : page,
      limit: 24,
      total: hasNext ? 0 : list.length,
    };
  },

  async detail(ctx, id) {
    const vid = String(id).split(',')[0].trim();
    if (!vid) return { list: [] };

    const { request } = ctx.lib.net;
    const headers = { 'User-Agent': UA, 'Accept': 'application/json' };
    const res = await request(detailUrl(vid), { headers });
    const d = parseJson(res);
    if (!d || !d.data) return { list: [] };

    const info = d.data;
    const cid = info.channelId;
    const albumId = info.albumId || vid;

    let remarks = '';
    try {
      const cats = (info.categories || []).map(function(c) { return c.name || c; }).join('\t');
      if (info.latestOrder) {
        remarks = '类型: ' + cats + '\t评分：' + (info.score || '') + '\n更新至：第' + info.latestOrder + '集(期)/共' + info.videoCount + '集(期)';
      } else {
        remarks = '类型: ' + cats + '\t评分：' + (info.score || '') + (info.period || '');
      }
    } catch (e) {
      remarks = info.subtitle || '';
    }

    let vsize = '579_772';
    try { vsize = info.imageSize[12]; } catch (e) {}

    let actor = '';
    let director = '';
    try {
      if (info.people && info.people.main_charactor) {
        actor = info.people.main_charactor.map(function(it) { return it.name; }).join(',');
      }
      if (info.people && info.people.director) {
        director = info.people.director.map(function(it) { return it.name; }).join(',');
      }
    } catch (e) {}

    const eps = await getEps(albumId, cid, info, request, headers);
    if (!eps.length && info.firstVideoUrl) {
      eps.push({ title: '第1集', url: info.firstVideoUrl });
    }

    const vod_play_url = eps.map(function(p, i) {
      return (p.title || ('第' + (i + 1) + '集')) + '$' + (p.url || '');
    }).join('#');

    const areas = (info.areas || []).join(',');

    const vod = {
      vod_id: vid,
      vod_name: info.name || '',
      vod_pic: (info.imageUrl || '').replace('.jpg', '_' + vsize + '.jpg?caplist=jpg,webp'),
      vod_remarks: remarks,
      vod_content: info.description || '',
      vod_year: String(info.period || '').split('-')[0],
      vod_actor: actor,
      vod_director: director,
      vod_area: areas,
      type_name: (info.categories || []).map(function(c) { return c.name || c; }).join(','),
      vod_play_from: '爱奇艺',
      vod_play_url: vod_play_url,
    };

    return { list: [vod] };
  },

  async search(ctx, wd, quick, pg) {
    const page = Math.max(1, parseInt(pg) || 1);
    const keyword = String(wd || '').trim();
    if (!keyword) return { list: [], page: page, pagecount: 1, limit: 24, total: 0 };

    const { request } = ctx.lib.net;
    const headers = { 'User-Agent': UA, 'Accept': 'application/json' };
    const res = await request(searchUrl(keyword, page), { headers });
    const d = parseJson(res);

    const items = ((d && d.data && d.data.docinfos) || []).map(function(it) {
      const info = it.albumDocInfo || {};
      let pic = info.albumVImage || '';
      if (pic) pic = pic.replace('.jpg', '_390_520.jpg?caplist=jpg,webp');
      return {
        vod_id: String(info.albumId || info.tvId || ''),
        vod_name: info.albumTitle || info.title || '',
        vod_pic: pic,
        vod_remarks: info.tvFocus || '',
        type_name: info.channel || '',
      };
    }).filter(function(v) { return v.vod_id && v.vod_name; });

    return {
      list: items,
      page: page,
      pagecount: items.length >= 24 ? page + 1 : page,
      limit: 24,
      total: items.length >= 24 ? 0 : items.length,
    };
  },

  play(ctx, flag, id, vipFlags) {
    if (!id) return { parse: 0, url: '' };
    const url = String(id);

    if (url.indexOf('iqiyi.com') >= 0 || url.indexOf('iq.com') >= 0) {
      return { parse: 1, url: url.split('?')[0], jx: 0 };
    }

    return { parse: 0, url: url };
  },
};
